package kg.megacom.students1.services;

import kg.megacom.students1.models.Student;
import kg.megacom.students1.models.StudentGroups;

public interface StudentGroupsService {
    StudentGroups createStudentGroups(StudentGroups studentGroups);
}
