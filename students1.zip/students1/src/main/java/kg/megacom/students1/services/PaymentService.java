package kg.megacom.students1.services;

import kg.megacom.students1.models.Payment;

public interface PaymentService {
    Payment createPayment(Payment payment);
}
