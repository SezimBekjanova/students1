package kg.megacom.students1.models;

import lombok.AccessLevel;
import lombok.Data;
import lombok.experimental.FieldDefaults;
import javax.persistence.*;
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
@Table(name = "students")
public class Student {
        @Id
        Long id;
        String name;
        String surname;
        String title;



        double hd;
        int ram;
        @Column(length = 10)
        String cd;
        double price;
        @ManyToOne
        @JoinColumn(name = "model")
        Product product;
}
