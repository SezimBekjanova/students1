package kg.megacom.students1.models.enums;

public enum PaymentStatus {
    UNPAID,
    PAID
}
