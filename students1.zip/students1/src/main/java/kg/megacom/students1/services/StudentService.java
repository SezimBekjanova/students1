package kg.megacom.students1.services;

import kg.megacom.students1.models.Student;

public interface StudentService {
    Student createStudent(Student student);
}
