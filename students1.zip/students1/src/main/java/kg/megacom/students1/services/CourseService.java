package kg.megacom.students1.services;

import kg.megacom.students1.models.Course;
import kg.megacom.students1.models.Group;

public interface CourseService {
    Course createCourse(Course course);
}
