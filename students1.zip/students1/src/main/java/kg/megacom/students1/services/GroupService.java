package kg.megacom.students1.services;

import kg.megacom.students1.models.Group;
import kg.megacom.students1.models.Student;

public interface GroupService {
    Group createGroup(Group group);
}
