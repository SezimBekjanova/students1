package kg.megacom.students1.models.enums;

public enum StudentStatus {
    STUDIES,
    NOT_STUDYING,
    EXPELLED,
    ACADEMIC_VACATION
}
