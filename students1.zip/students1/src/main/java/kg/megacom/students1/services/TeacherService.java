package kg.megacom.students1.services;

import kg.megacom.students1.models.Teacher;

public interface TeacherService {
    Teacher createTeacher(Teacher teacher);}
