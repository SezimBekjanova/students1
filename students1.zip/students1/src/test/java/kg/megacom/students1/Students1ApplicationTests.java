package kg.megacom.students1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Students1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
